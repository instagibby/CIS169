﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ALM.MathLibrary
{
    public class BasicMathLibrary
    {
        public int Add(int p1, int p2)
        {
            return (p1 + p2);
        }
    }
}